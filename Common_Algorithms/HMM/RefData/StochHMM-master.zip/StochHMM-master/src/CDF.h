//
//  CDF.h
//  StochHMM
//
//  Created by Paul Lott on 10/11/12.
//  Copyright (c) 2012 Korf Lab, Genome Center, UC Davis, Davis, CA. All rights reserved.
//

#ifndef __StochHMM__CDF__
#define __StochHMM__CDF__

#include <iostream>

#endif /* defined(__StochHMM__CDF__) */
