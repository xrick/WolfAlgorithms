//
//  MotifScorer.h
//  StochHMM
//
//  Created by Paul Lott on 2/14/13.
//  Copyright (c) 2013 Korf Lab, Genome Center, UC Davis, Davis, CA. All rights reserved.
//

#ifndef __StochHMM__MotifScorer__
#define __StochHMM__MotifScorer__

#include <iostream>
const char usage[]  = "\n\
MotifScorer .... \n\
\n\
Written by Paul Lott at University of California, Davis\n\
Please direct any questions, suggestions or bugs reports to Paul Lott at plott@ucdavis.edu\n\
\n\
";



#endif /* defined(__StochHMM__MotifScorer__) */
