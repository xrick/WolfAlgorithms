//
//  stateInfo.h
//  StochHMM
//
//  Created by Paul Lott on 2/26/13.
//  Copyright (c) 2013 Korf Lab, Genome Center, UC Davis, Davis, CA. All rights reserved.
//

#ifndef __StochHMM__stateInfo__
#define __StochHMM__stateInfo__

#include <iostream>

#endif /* defined(__StochHMM__stateInfo__) */
