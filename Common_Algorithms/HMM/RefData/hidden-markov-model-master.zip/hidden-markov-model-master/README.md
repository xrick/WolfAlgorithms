# Hidden Markov Model
First order HMM with Viterbi, Forward-Backward and Baum-Welch implementations
