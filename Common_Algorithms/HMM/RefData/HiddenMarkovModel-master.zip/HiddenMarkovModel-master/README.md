## Python implementation of Hidden Markov Model

* Usage:
  1. Training Hidden Markov Model:
    python 1_train_hmm.py

  2. Chinese POS tagging:
    python 2_pos_test.py
