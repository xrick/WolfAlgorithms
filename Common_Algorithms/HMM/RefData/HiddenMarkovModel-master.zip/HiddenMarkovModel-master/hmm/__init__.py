"""
HiddenMarkovModel
"""

from HiddenMarkovModel import *
