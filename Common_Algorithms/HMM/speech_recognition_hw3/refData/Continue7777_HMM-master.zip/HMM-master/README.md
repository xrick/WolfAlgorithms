# HMM
basic hmm 
